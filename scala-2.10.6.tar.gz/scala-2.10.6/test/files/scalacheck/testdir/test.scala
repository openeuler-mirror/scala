import org.scalacheck._






object Test extends Properties("Nothing") {
  val d = Dependency.v
}
