



object Dependency {
  val v = 1
}
