package t722;
trait IfEse extends ScanBased {
  object condition extends WhitespaceLink;
}
