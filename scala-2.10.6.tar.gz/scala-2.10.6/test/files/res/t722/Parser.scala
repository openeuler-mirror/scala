
package t722;
trait Parser {
  trait Link  {
    def foo() = {} 
  }
}

