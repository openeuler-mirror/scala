package t785;
trait ScalaTrees extends ScalaNewTyper {
  trait TraitClassImpl extends HasArgsTypeParametersImpl {
    argss(null);
    protected def argss(tree : String) : List[List[String]] = Nil;
  }
}
