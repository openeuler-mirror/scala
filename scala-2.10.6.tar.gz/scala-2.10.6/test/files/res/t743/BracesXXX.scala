package t743;
trait BracesXXX extends ParserXXX {
  trait Matchable extends IsLinked { 
    def foo : NodeImpl = null;
  }
}
