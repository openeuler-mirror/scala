package t831;
abstract class NewScalaTestXXX extends NewScalaParserXXX;
