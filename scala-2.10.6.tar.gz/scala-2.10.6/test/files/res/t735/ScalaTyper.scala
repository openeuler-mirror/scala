
package t735;
trait ScalaTyper extends ScalaExpressions {
  val values = new ValueFactory {}
}
