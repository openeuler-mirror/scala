package a

import d.D._

object A {
  Seq.empty[Byte].toArray.toSeq
}
