package c

class C(key: String = "", componentStates: String = "")
