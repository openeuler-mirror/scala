package d

import c.C

object D {
  implicit def c2s(c: C): String = ""
}
