package b

import c.C

class B {
  new C("")
}
