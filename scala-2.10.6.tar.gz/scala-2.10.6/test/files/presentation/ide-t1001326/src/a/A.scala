package a

class A {
  def foo(s: String) = s + s
}