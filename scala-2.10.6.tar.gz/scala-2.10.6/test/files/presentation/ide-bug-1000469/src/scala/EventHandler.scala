package scala

class EventHandler {
  @transient private val foo = 2
}