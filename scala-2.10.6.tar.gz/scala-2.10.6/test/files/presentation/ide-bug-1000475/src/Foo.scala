class Foo {
  val v = new Object
  v.toS/*!*/
  
  val m = Map(1 -> new Object)
  m(1).toS/*!*/
  m(1)./*!*/
  println()
}