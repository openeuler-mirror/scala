package test

/* completion on empty class and object */

class Completion1 {
  /*_*/
}

object Completion2 {
  /*_*/
}

