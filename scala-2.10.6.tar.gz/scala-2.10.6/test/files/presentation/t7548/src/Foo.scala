object Foo {
  def foo(x: Int) = {}
  def foo(x: String) = {}
  def foo(x: Int, y: String) = {}
  
  foo(2)
}