package a

object A {
  val tagString = "foo"
  Seq.empty[Byte].toArray.toSeq
}
