package b

class Bar extends a.Foo {
  println(x)
}
