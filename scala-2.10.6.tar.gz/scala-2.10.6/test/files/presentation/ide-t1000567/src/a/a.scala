package a

class Foo {
  protected[Foo] var x = 0
}
