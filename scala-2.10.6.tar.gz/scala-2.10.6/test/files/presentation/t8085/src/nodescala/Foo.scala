package nodescala

class Foo
