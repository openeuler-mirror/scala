import scala.tools.nsc.interactive.tests._

object Test extends InteractiveTest
