import scala.tools.nsc.interactive.tests.InteractiveTest

object Test extends InteractiveTest