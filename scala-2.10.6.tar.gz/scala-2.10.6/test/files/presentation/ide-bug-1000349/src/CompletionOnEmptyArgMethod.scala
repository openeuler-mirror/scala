object Foo {
  new Foo().foo. /*!*/
}

class Foo {
  def foo = this
}