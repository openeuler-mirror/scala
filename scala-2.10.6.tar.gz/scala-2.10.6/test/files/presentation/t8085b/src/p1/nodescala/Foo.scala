package p1
package nodescala

class Foo
