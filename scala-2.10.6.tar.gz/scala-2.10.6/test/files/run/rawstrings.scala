object Test extends App {
  println(raw"[\n\t'${'"'}$$\n]")
}
