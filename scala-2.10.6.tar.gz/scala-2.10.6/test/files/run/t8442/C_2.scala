class C_2 {
  def foo(b: B_1) {
    b.get()
  }
}
