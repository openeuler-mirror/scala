public class B_1 {
	@A_1 public String get() { return ""; }
}
