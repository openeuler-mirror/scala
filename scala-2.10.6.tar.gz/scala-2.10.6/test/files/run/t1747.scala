object Foo extends Foo {
  def f {}
}
class Foo

object Test extends App { Foo }
