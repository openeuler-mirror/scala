object Test extends App {
  def foo() = {
    while (true) {
      try {
      } catch {
        case ex: Exception =>
      }
    }
  }
}
