object Test extends App {
  Macros.foo
}