class A {
  class B(val a: Int)
}
