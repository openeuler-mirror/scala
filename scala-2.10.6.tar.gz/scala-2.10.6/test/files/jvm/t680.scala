object Test {
  def main(args:Array[String]) {
    val sb = new java.lang.StringBuilder() // use Java 1.5
    sb.setLength(0)
  }
}
