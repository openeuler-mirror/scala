object Test {
  def main(args: Array[String]) {
    println(classOf[test.NestedAnnotations].getName)
  }
}
