class ScalaClient_1 {
  def foo() = {
    (null: A).f()
    (null: B1).f()
    (null: B2).f()
    (null: B3).f()
    (null: B4).f()
  }
}
