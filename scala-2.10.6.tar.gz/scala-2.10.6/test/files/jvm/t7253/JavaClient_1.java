public class JavaClient_1 {
  int foo() {
    ((A) null).f();
    ((B1) null).f();
    ((B2) null).f();
    ((B3) null).f();
    return ((B4) null).f();
  }
}
