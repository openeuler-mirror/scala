public class Defs {
    /** @deprecated */
    public int i = 1;

    /** @deprecated */
    public int bar() { return 0; }

    /** @deprecated */
    public class Inner {
        public int buz() { return 0; }
    }
}
