import scala.tools.partest.ReplTest

object Test extends ReplTest {
  def code = """
<city name="San Jos&eacute;"/>
  """
}