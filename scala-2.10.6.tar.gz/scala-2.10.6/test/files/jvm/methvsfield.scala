// bug #1062
object Test extends App {
  println((new MethVsField).three)
}
