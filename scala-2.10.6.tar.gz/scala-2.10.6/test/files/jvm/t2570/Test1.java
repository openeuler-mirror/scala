public class Test1<T extends Test3> {
}