class Test2 extends Test1[Test3[Test4]]
class Test4
object Test extends Application {} 