package test

class PolymorphicException[T] extends Exception
