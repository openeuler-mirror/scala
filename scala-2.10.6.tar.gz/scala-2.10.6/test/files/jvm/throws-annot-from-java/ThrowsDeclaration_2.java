package test;

public class ThrowsDeclaration_2 {
	public void foo() throws IllegalStateException {};
	public void bar() throws PolymorphicException {};
}
