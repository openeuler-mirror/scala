object Test extends Application {
  @Hello
  def foo() { }
}
