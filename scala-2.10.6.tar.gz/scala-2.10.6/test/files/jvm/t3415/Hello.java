public @interface Hello {
    String msg() default "hoi";
}
