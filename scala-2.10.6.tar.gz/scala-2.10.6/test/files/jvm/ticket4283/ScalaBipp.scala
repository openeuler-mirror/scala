package test

class ScalaBipp extends AbstractFoo {
  def make: Option[ScalaBipp] = Option(this)
}
