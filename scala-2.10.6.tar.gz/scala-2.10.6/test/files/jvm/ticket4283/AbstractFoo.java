package test;

/* package private */ class AbstractFoo {
  public int t;
}
