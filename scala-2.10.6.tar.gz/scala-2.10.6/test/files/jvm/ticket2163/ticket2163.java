import java.util.*;

public class ticket2163 {
    public void test() {
      List<Integer> array = new ArrayList<Integer>();
      Ticket2163Scala<List> foo = new Ticket2163Scala<List>(array);
      foo.bar(array);
    }
}
