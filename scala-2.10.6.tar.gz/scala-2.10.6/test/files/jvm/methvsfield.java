// This should be compiled with javac and saved
// in ../lib/methvsfield.jar .
class MethVsField 
{
  int three = 3;

  int three() 
  { 
    return 3;
  }
}
