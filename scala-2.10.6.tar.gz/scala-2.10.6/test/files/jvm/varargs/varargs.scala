





object Test {
  def main(args: Array[String]) {
    JavaClass.callSomeAnnotations
  }
}










