interface JI {
   void varArgsMethod( String ... args );
}
