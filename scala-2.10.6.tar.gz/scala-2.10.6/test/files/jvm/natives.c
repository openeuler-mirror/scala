#include "natives.h"

JNIEXPORT jstring JNICALL Java_Test_00024_sayHello
  (JNIEnv *env, jobject thisobject, jstring js)

{
    return js;
}
