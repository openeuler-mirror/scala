public class Test {
    public static void main(String[] args) {
        Object o = new Object();
        System.out.println(o instanceof MyTrait);
    }
}
