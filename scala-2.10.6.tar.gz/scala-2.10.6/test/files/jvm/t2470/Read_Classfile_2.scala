class Read {
  val t = Test
}
