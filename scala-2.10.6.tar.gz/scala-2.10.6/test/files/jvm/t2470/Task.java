class Task {
    public enum Scope { ACTION, HIKA }
}
