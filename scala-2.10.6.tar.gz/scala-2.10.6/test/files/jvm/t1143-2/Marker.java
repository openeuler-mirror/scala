import java.io.Serializable;

public interface Marker extends Serializable {
}
