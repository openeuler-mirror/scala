object Test extends App {
  def bar(x:Int) = { return x; x }  // NPE
}
