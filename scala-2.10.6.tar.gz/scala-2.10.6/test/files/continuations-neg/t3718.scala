object Test {
  scala.util.continuations.reset((_: Any).##)
}
